var index;
var coll=document.getElementsByClassName("collapsible");
for (index=0; index<coll.length; index++) {
  coll[index].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight)
      content.style.maxHeight=null;
     else 
      content.style.maxHeight=content.scrollHeight + "px";   
  }
  );
}

